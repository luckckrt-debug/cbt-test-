'use client';
import React, { useState, useEffect } from 'react';

const generateQuestions = () => {
  const topics = ['IVC', 'Vedic Culture', 'Later Mughals', 'Reasoning: Cube', 'Reasoning: Clock', 'Reasoning: Wind', 'Current Affairs'];
  const difficulties = ['Easy', 'Medium', 'Hard'];
  
  let qList = [];
  for (let i = 1; i <= 200; i++) {
    const topic = topics[(i - 1) % topics.length];
    const diff = difficulties[i % difficulties.length];
    qList.push({
      id: i,
      question: `Q${i}. [${topic} - ${diff}] Which of the following statements is correct regarding the core characteristics and historical timeline of this topic?`,
      options: [
        `Option A: Primary structural hypothesis of ${topic}`,
        `Option B: Secondary evolutionary phase and documentation`,
        `Option C: Chronological anomaly identified in recent excavations/analysis`,
        `Option D: None of the above / Insufficient empirical data`
      ],
      correctAnswer: 0,
      explanation: `Detailed explanation for Question ${i}: Based on standard curriculum guidelines for ${topic}, Option A is accurate due to established academic consensus.`
    });
  }
  return qList;
};

const ALL_QUESTIONS = generateQuestions();

export default function CBTTestApp() {
  const [testState, setTestState] = useState('instructions');
  const [currentIndex, setCurrentIndex] = useState(0);
  const [answers, setAnswers] = useState({});
  const [marked, setMarked] = useState({});
  const [timeLeft, setTimeLeft] = useState(7200);

  useEffect(() => {
    let timer;
    if (testState === 'running' && timeLeft > 0) {
      timer = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            clearInterval(timer);
            setTestState('submitted');
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [testState, timeLeft]);

  const formatTime = (secs) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const handleSelectOption = (optIdx) => {
    setAnswers({ ...answers, [currentIndex]: optIdx });
  };

  const handleClearResponse = () => {
    const updated = { ...answers };
    delete updated[currentIndex];
    setAnswers(updated);
  };

  const handleToggleMark = () => {
    setMarked({ ...marked, [currentIndex]: !marked[currentIndex] });
  };

  const getStats = () => {
    let attempted = Object.keys(answers).length;
    let correct = 0;
    Object.keys(answers).forEach((qId) => {
      if (answers[qId] === ALL_QUESTIONS[qId].correctAnswer) {
        correct++;
      }
    });
    let incorrect = attempted - correct;
    let unattempted = 200 - attempted;
    let score = (correct * 4) - (incorrect * 1);
    return { attempted, correct, incorrect, unattempted, score };
  };

  if (testState === 'instructions') {
    return (
      <div className="min-h-screen bg-slate-100 flex items-center justify-center p-4 font-sans">
        <div className="bg-white max-w-2xl w-full rounded-xl shadow-lg p-8 border border-slate-200">
          <div className="flex items-center justify-between border-b pb-4 mb-6">
            <h1 className="text-2xl font-bold text-slate-800">CBT Online Mock Test Platform</h1>
            <span className="bg-blue-100 text-blue-800 text-xs font-semibold px-2.5 py-1 rounded">Testbook Standard</span>
          </div>
          <div className="space-y-4 text-slate-600 text-sm mb-6">
            <p><strong>Total Questions:</strong> 200 Questions</p>
            <p><strong>Duration:</strong> 120 Minutes (2 Hours)</p>
            <p><strong>Subjects:</strong> IVC, Vedic Culture, Later Mughals, Reasoning (Cube, Clock, Wind), Current Affairs.</p>
            <p><strong>Marking Scheme:</strong> +4 for correct answer, -1 for incorrect.</p>
          </div>
          <button 
            onClick={() => setTestState('running')}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 rounded-lg transition"
          >
            I am ready to begin
          </button>
        </div>
      </div>
    );
  }

  if (testState === 'submitted') {
    const stats = getStats();
    return (
      <div className="min-h-screen bg-slate-100 p-6 font-sans">
        <div className="max-w-4xl mx-auto bg-white rounded-xl shadow-lg p-8 border border-slate-200">
          <h1 className="text-3xl font-bold text-slate-800 mb-2">Test Performance Report</h1>
          <p className="text-slate-500 mb-6">Comprehensive analysis of your 200-question CBT evaluation.</p>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            <div className="bg-blue-50 p-4 rounded-lg border border-blue-100 text-center">
              <p className="text-slate-500 text-xs font-semibold">Total Score</p>
              <p className="text-2xl font-bold text-blue-600">{stats.score} / 800</p>
            </div>
            <div className="bg-emerald-50 p-4 rounded-lg border border-emerald-100 text-center">
              <p className="text-slate-500 text-xs font-semibold">Correct Answers</p>
              <p className="text-2xl font-bold text-emerald-600">{stats.correct}</p>
            </div>
            <div className="bg-rose-50 p-4 rounded-lg border border-rose-100 text-center">
              <p className="text-slate-500 text-xs font-semibold">Incorrect Answers</p>
              <p className="text-2xl font-bold text-rose-600">{stats.incorrect}</p>
            </div>
            <div className="bg-amber-50 p-4 rounded-lg border border-amber-100 text-center">
              <p className="text-slate-500 text-xs font-semibold">Unattempted</p>
              <p className="text-2xl font-bold text-amber-600">{stats.unattempted}</p>
            </div>
          </div>

          <h3 className="text-lg font-bold text-slate-800 mb-4">Solution Key & Review</h3>
          <div className="space-y-4 max-h-96 overflow-y-auto pr-2">
            {ALL_QUESTIONS.map((q, idx) => (
              <div key={idx} className="p-4 rounded-lg border border-slate-200 bg-slate-50 text-sm">
                <p className="font-semibold text-slate-800 mb-1">{q.question}</p>
                <p className="text-emerald-700 font-medium">Correct: {q.options[q.correctAnswer]}</p>
                <p className="text-slate-500 text-xs mt-1">Explanation: {q.explanation}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  const q = ALL_QUESTIONS[currentIndex];

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col font-sans select-none">
      <header className="bg-blue-900 text-white px-6 py-3 flex justify-between items-center shadow">
        <h1 className="font-bold text-lg">CBT Online Assessment Engine</h1>
        <div className="flex items-center space-x-6">
          <div className="bg-blue-800 px-3 py-1.5 rounded text-sm font-mono">
            Time Left: <span className="font-bold text-amber-300">{formatTime(timeLeft)}</span>
          </div>
          <button 
            onClick={() => setTestState('submitted')}
            className="bg-emerald-600 hover:bg-emerald-700 px-4 py-1.5 rounded text-sm font-semibold transition"
          >
            Submit Test
          </button>
        </div>
      </header>

      <div className="flex-1 flex flex-col md:flex-row">
        <div className="flex-1 p-6 flex flex-col justify-between bg-white border-r border-slate-200">
          <div>
            <div className="flex justify-between items-center mb-6 border-b pb-3">
              <span className="text-sm font-bold text-slate-500 uppercase tracking-wide">Question {currentIndex + 1} of 200</span>
              <span className="bg-slate-100 text-slate-700 text-xs px-2.5 py-1 rounded font-medium">Marks: +4.0, -1.0</span>
            </div>
            
            <h2 className="text-lg font-semibold text-slate-800 mb-6">{q.question}</h2>

            <div className="space-y-3">
              {q.options.map((opt, oIdx) => (
                <label 
                  key={oIdx} 
                  className={`flex items-center p-3 rounded-lg border cursor-pointer transition ${
                    answers[currentIndex] === oIdx ? 'border-blue-500 bg-blue-50 text-blue-900' : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                  }`}
                >
                  <input 
                    type="radio" 
                    name={`q-${currentIndex}`} 
                    checked={answers[currentIndex] === oIdx}
                    onChange={() => handleSelectOption(oIdx)}
                    className="mr-3"
                  />
                  <span>{opt}</span>
                </label>
              ))}
            </div>
          </div>

          <div className="flex justify-between items-center pt-6 border-t mt-6">
            <div className="space-x-2">
              <button 
                onClick={handleToggleMark}
                className={`px-4 py-2 rounded text-sm font-semibold border ${
                  marked[currentIndex] ? 'bg-amber-500 text-white border-amber-500' : 'border-slate-300 text-slate-700 hover:bg-slate-100'
                }`}
              >
                {marked[currentIndex] ? 'Unmark Review' : 'Mark for Review'}
              </button>
              <button 
                onClick={handleClearResponse}
                className="px-4 py-2 rounded text-sm font-semibold border border-slate-300 text-slate-700 hover:bg-slate-100"
              >
                Clear Response
              </button>
            </div>

            <div className="space-x-2">
              {currentIndex > 0 && (
                <button 
                  onClick={() => setCurrentIndex(currentIndex - 1)}
                  className="px-5 py-2 rounded text-sm font-semibold bg-slate-200 text-slate-700 hover:bg-slate-300"
                >
                  Previous
                </button>
              )}
              {currentIndex < 199 && (
                <button 
                  onClick={() => setCurrentIndex(currentIndex + 1)}
                  className="px-5 py-2 rounded text-sm font-semibold bg-blue-600 text-white hover:bg-blue-700"
                >
                  Save & Next
                </button>
              )}
            </div>
          </div>
        </div>

        <div className="w-full md:w-80 bg-slate-50 p-4 border-t md:border-t-0 flex flex-col">
          <h3 className="font-bold text-slate-700 mb-3 text-sm">Question Palette</h3>
          <div className="grid grid-cols-5 gap-2 overflow-y-auto max-h-[500px] p-2 bg-white rounded border border-slate-200">
            {ALL_QUESTIONS.map((_, idx) => {
              let bg = 'bg-slate-100 text-slate-700 border-slate-300';
              if (answers[idx] !== undefined) bg = 'bg-emerald-600 text-white border-emerald-600';
              if (marked[idx]) bg = 'bg-purple-600 text-white border-purple-600';
              
              return (
                <button
                  key={idx}
                  onClick={() => setCurrentIndex(idx)}
                  className={`h-9 rounded font-semibold text-xs border flex items-center justify-center transition ${bg} ${currentIndex === idx ? 'ring-2 ring-offset-1 ring-blue-500' : ''}`}
                >
                  {idx + 1}
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}