@echo off
echo Initializing Git repository...
git init
git add .
git commit -m "Automated commit: CBT 200-question mock test app"
git branch -M main
set /p REPO_URL="Enter your GitHub Repository URL (e.g., https://github.com/username/repo.git): "
git remote add origin %REPO_URL%
git push -u origin main
echo Done! Pushed to GitHub successfully.
pause
