#!/bin/bash
echo "Initializing Git repository..."
git init
git add .
git commit -m "Automated commit: CBT 200-question mock test app"
git branch -M main
echo "Enter your GitHub Repository URL (e.g., https://github.com/username/repo.git):"
read REPO_URL
git remote add origin $REPO_URL
git push -u origin main
echo "Done! Pushed to GitHub successfully."
