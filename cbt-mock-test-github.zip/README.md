# CBT Mock Test Platform

## Quick GitHub Push Instructions
1. Extract this zip folder.
2. Create an empty repository on GitHub.
3. Run `push.bat` (if on Windows) or `push.sh` (if on Mac/Linux) and paste your repository URL when prompted.
4. Deploy on Vercel instantly!
